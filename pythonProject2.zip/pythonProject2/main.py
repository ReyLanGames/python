import random

class Human:

    def __init__(self, name ='Human', job=None, home = None, car = None):
        self.name = name
        self.job =job
        self.home = home
        self.car = car
        self.money = 1500
        self.gladness = 200
        self.satiety = 100

    def get_home(self):
        self.home =Home()

    def get_car(self):
        self.car = Auto(brands_of_car)

    def get_job(self):
        if self.car.drive():
            pass
        else:
            self.to_repair()
            return
        self.job = Job(job_list)

    def eat(self):
        if self.home.food <=0:
            self.shopping('food')
        else:
            if self.satiety >=100:
                self.satiety =100
                return
            self.satiety+=5
            self.home.food-=5
    def work(self):
        if self.car.drive:
            pass
        else:
            if self.car.fuel <=20:
                print('ЗАПРАВСЯ!!!')
                self.shopping('fuel')
            else:
                self.to_repair()
                return
        self.money += self.job.salary
        self.gladness -= self.job.gladness_less
        self.satiety -=10

    def shopping(self, manage):
        if self.car.drive():
            pass
        else:
            if self.car.fuel <20:
                manage = 'fuel'
            else:
                self.to_repair()
                return
        if manage == 'fuel':
            print('I BUY FUEL')
            self.money-=60
            self.car.fuel+=150
        elif manage == 'food':
            print('I BUY EAT')
            self.money -=50
            self.home.food+=50

        elif manage == 'sweets':
            print('SWEETS!!!')
            self.gladness+=50
            self.satiety+=2
            self.money-=15

    def chill(self):
        self.gladness+=20
        self.home.mess+=10

    def clean_home(self):
        self.home.mess =0
        self.gladness -=20



    def to_repair(self):
        self.car.strength+=150
        self.money-=100

    def days_indexes(self,day):
        day = f" Today is {day} - my name is -{self.name}"
        print(f"{day:=^50}")
        human_ind = self.name +'- name'
        print(f"{human_ind:*^50} \n")
        print(f"Money - {self.money}")
        print(f"Gladness - {self.gladness}")
        print(f"satiety - {self.satiety}")
        home_ind='HOme!!'
        print(f"{home_ind:*^50}")
        print(f"Food - {self.home.food}")
        print(f"Mess - {self.home.mess}")
        car_ind='Car!!'
        print(f" {car_ind:*^50}")
        print(f"Car - {self.car.brand}")
        print(f"consumption - {self.car.consumption}")

        job_ind="Job!"
        print(f"{job_ind:-^50}")
        print(f"My job is - {self.job}")
        print(f"My salary is - {self.job}")


    def is_alive(self):
        if self.gladness <0:
            print('Depresia')
            return False
        if self.satiety <0 :
            print('DEAD')
            return False
        if self.money<0:
            print('WOOOW ! You are bomz!!')
            return False

    def live(self, day):
        if self.is_alive()==False:
            return False
        if self.home is None:
            self.get_home()
        if self.car is None:
            self.get_car()
        if self.job is None:
            self.get_job()
            print('I have not a job!')
            print(f" my job is {self.job}")
        self.days_indexes(day)
        dice = random.randint(1,4)
        if self.satiety<20:
            self.eat()
            print('Я поїв')
        elif self.gladness<20:
            if self.home.mess >15:
                print('CLEAN!')
                self.clean_home()
            else:
                self.chill()
                print('Ми відпочили!')
        elif self.money <0:
            print('Йди працюй!')
            self.work()
        elif self.car.strength<15:
            self.to_repair()
        elif dice==1:
            self.work()
            print('Йди працюй!')
        elif dice==2:
            self.clean_home()
            print('CLEAN!')
        elif dice==3:
            self.chill()
            print('Ми відпочили!')
        elif dice ==4:
            self.shopping(manage='sweets')
            print('SWEETS!!!')

    def get_pet(self, pet_species='Cat'):
        self.pet = Pet(name=f"My {pet_species}")
        print(f"I have a new pet: {self.pet.name}")

    def play_with_pet(self):
        if hasattr(self, 'pet'):
            self.pet.play()
        else:
            print("I don't have a pet yet!")







class Auto:
    def __init__(self, brand_list):
        self.brand = random.choice(list(brand_list))
        self.fuel = brand_list[self.brand]['fuel']
        self.strength = brand_list[self.brand]['strength']
        self.consumption = brand_list[self.brand]['consumption']

    def drive(self):
        if self.strength >0 and self.fuel >=self.consumption:
            self.strength +=1
            return False
        else:
            print('CANT MOVE - CAR!! HELP!! FUEL!!')
            return False

class Pet:
    def __init__(self, name='Cat'):
        self.name = name
        self.gladness = 100
        self.satiety = 50

    def play(self):
        print(f'{self.name} is playing!')
        self.gladness += 10
        self.satiety -= 5

class Home:
    def __init__(self):
        self.mess = 0
        self.food = 0

class Job:
    def __init__(self, job_list):
        self.job = random.choice(list(job_list))
        self.salary = job_list[self.job]['salary']
        self.gladness_less = job_list[self.job]['gladness_less']
job_list = {
    "JavaScript razrab":
        {"salary":50, "glagness less":10 },
    "Python razrab":
        {"salary": 40, "glagness less": 3},
    "C++ razrab":
        {"salary": 45, "glagness less": 25},
    "Rust razrab":
        {"salary": 70, "glagness less": 1}
}

animal_list = ['Dog', 'Cat', 'Parrot', 'Fish', 'Hamster']



brands_of_car={'Mercedes':{'fuel':100, 'strength':100, 'consumption':15},
               'Volswagen':{'fuel':120, 'strength':200, 'consumption':10},
               'Porshe':{'fuel':80, 'strength':10, 'consumption':20}}


ivan=Human(name='Ivan')
ivan.get_home()
ivan.get_car()
ivan.get_job()
ivan.get_pet(pet_species=random.choice(animal_list))
ivan.play_with_pet()
for day in range(1,8):
    if ivan.live(day)==False:
        break